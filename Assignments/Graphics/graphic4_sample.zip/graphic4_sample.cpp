#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_gfx.h>
#include <string>
#include <math.h>
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian);
void window_color(SDL_Renderer *Renderer, int R, int G, int B);


using namespace std;


int main( int argc, char * argv[] )
{
    int W =700,c=0,p=0;
    int L = 1500;
    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
    Uint32 WND_flags = SDL_WINDOW_SHOWN;
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    SDL_Init( SDL_flags );
    SDL_CreateWindowAndRenderer( L, W, WND_flags, &m_window, &m_renderer );
    SDL_RaiseWindow(m_window);
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    window_color(m_renderer,98,232,208);
    SDL_Event *event = new SDL_Event();

int dx=20,dy=10,x=1300,y=360,ax=0,ay=0;
double t=0;
    while (1)
    {
    window_color(m_renderer,98,232,208);
    rect(m_renderer,0,0,1500,30,0,0,0,1);
    rect(m_renderer,0,30,30,640,0,0,0,1);
    rect(m_renderer,0,670,1500,30,0,0,0,1);
    rect(m_renderer,1470,30,30,640,0,0,0,1);
    filledEllipseRGBA(m_renderer, x, y, 40, 40, 100, 200, 0, 255);


      SDL_PollEvent(event);
        if(event ->type == SDL_MOUSEBUTTONDOWN){

        if(SDL_BUTTON_LEFT)
            {
                 filledEllipseRGBA(m_renderer,event->button.x , event->button.y, 40, 40, 34, 20, 255, 255);
                c=1;

            }

        }

         SDL_PollEvent(event);
        if(event->type == SDL_MOUSEMOTION){
                if(c==1)
                {
             filledEllipseRGBA(m_renderer,event->button.x , event->button.y, 40, 40, 34, 20,255, 255);
                }

        }



        SDL_PollEvent(event);
        if(event->type == SDL_MOUSEBUTTONUP){

       if( SDL_BUTTON_LEFT)
            {
                c=0;
        }

        }


           SDL_PollEvent(event);
        if(event ->type == SDL_MOUSEBUTTONDOWN){
              if(SDL_BUTTON_RIGHT)
            {
                 ax=(event->button.x-x)/10;
                ay=(event->button.y-y)/10;
                p=1;
            }
        }







           SDL_PollEvent(event);
        if(event->type == SDL_MOUSEMOTION){
          if(p==1){
                 ax=(event->button.x-x)/10;
                ay=(event->button.y-y)/10;
                }
        }


        SDL_PollEvent(event);
        if(event->type == SDL_MOUSEBUTTONUP){
       if( SDL_BUTTON_RIGHT)
            {
                p=0;
        }
        }




    if(y<=70){dy=-dy;y=71;}
    if(x<=70){dx=-dx;x=71;}
   if(x>=1430){dx=-dx;x=1399;}
if(y>=630) {dy=-dy;y=629;}

  x+=ax*0.5*t*t+dx*t;
   y+=ay*0.5*t*t+dy*t;
    t+=0.001;


     SDL_Delay(25);
    SDL_RenderPresent(m_renderer);

  SDL_RenderClear(m_renderer);

        if( SDL_PollEvent( event ) )
            {
                if( event->type == SDL_KEYDOWN )
                {
                    switch( event->key.keysym.sym )
                    {
                        case SDLK_ESCAPE:
                            {
                                SDL_DestroyWindow( m_window );
                                SDL_DestroyRenderer( m_renderer );
                                IMG_Quit();
                                SDL_Quit();
                                return 0;
                            }


                    }
                }
            }
        }
}


void window_color(SDL_Renderer *Renderer, int R, int G, int B)
{
    SDL_SetRenderDrawColor(Renderer,R,G,B,255);
    SDL_RenderClear(Renderer);
}
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian)
{

    SDL_Rect rectangle ;
    rectangle.x = x;
    rectangle.y = y;
    rectangle.w = w;
    rectangle.h = h;

    SDL_SetRenderDrawColor(Renderer, R, G, B, 255);
    SDL_RenderFillRect(Renderer, &rectangle);
    SDL_RenderDrawRect(Renderer, &rectangle);
    //SDL_RenderPresent(Renderer);
}
