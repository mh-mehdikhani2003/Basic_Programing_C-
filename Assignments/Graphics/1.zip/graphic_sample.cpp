#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_gfx.h>
#include <string>
#include <math.h>
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian);
void window_color(SDL_Renderer *Renderer, int R, int G, int B);
using namespace std;

int main( int argc, char * argv[] )
{
    int W =700;
    int L = 1500;

    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
    Uint32 WND_flags = SDL_WINDOW_SHOWN;
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    SDL_Init( SDL_flags );
    SDL_CreateWindowAndRenderer( L, W, WND_flags, &m_window, &m_renderer );
    SDL_RaiseWindow(m_window);
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    window_color(m_renderer,98,232,208);

    SDL_Event *event = new SDL_Event();
    int dx=2,dy=2,x=100,y=20,x0=1150    ,y0=20,dy0=4,dx0=-4;
    int x1=x,x2=x+250,x3=x,x4=x+250;
    int x01=x0,x02=x0+250,x03=x0,x04=x0+250;
    int y1=y,y2=y,y3=y+250,y4=y+250;
    int y01=y0,y02=y0,y03=y0+250,y04=y0+250,G=255,B=255;
    while (1)
    {
    window_color(m_renderer,98,232,208);
    rect(m_renderer,100,10,1300,10,0,0,0,1);
    rect(m_renderer,100,680,1300,10,0,0,0,1);
    rect(m_renderer,90,20,10,660,0,0,0,1);
    rect(m_renderer,1400,20,10,660,0,0,0,1);
    rect(m_renderer,x1,y1,250,250,159,22,255,1);
    rect(m_renderer,x01,y01,250,250,100,22,255,1);
    x1+=dx;x2+=dx;x3+=dx;x4+=dx;
 y1+=dy,    y2+=dy;y3+=dy;y4+=dy;
y01+=dy0;y02+=dy0;y03+=dy0;y04+=dy0;
x01+=dx0;x02+=dx0;x03+=dx0;x04+=dx0;

if((x1>=x01 && x1<=x02)&&(y1>=y01 && y1<=y03)) {rect(m_renderer,x1,y1,(int)fabs(x1-x04),(int)fabs(y1-y04),255,G-1,B-3,1) ;if(G!=0){G-=1;B-=1;}}
if((x2>=x01 && x2<=x02)&&(y2>=y01 && y2<=y03)) {rect(m_renderer,x03,y2,(int)fabs(x2-x03),(int)fabs(y2-y03),255,G-1,B-1,1) ;if(G!=0){G-=1;B-=1;}}
if((x3>=x01 && x3<=x02)&&(y3>=y01 && y3<=y03)){rect(m_renderer,x3,y02,(int)fabs(x3-x02),(int)fabs(y3-y02),255,G-1,B-1,1) ;if(G!=0){G-=1;B-=1;}}
if((x4>=x01 && x4<=x02)&&(y4>=y01 && y4<=y03)){rect(m_renderer,x01,y01,(int)fabs(x01-x4),(int)fabs(y01-y4),255,G-1,B-1,1) ;if(G!=0){G-=1;B-=1;}}
if(!(((x1>=x01 && x1<=x02)&&(y1>=y01 && y1<=y03))||((x2>=x01 && x2<=x02)&&(y2>=y01 && y2<=y03))||((x3>=x01 && x3<=x02)&&(y3>=y01 && y3<=y03))||((x4>=x01 && x4<=x02)&&(y4>=y01 && y4<=y03)))) {G=255;B=255;}
  if(x1<=100|| x1>=1150) {dx=-dx;}
    if(x01<=100 || x01>=1150) {dx0=-dx0;}
    if(y1<=20 || y1>=430) {dy=-dy;}
    if(y01<=20 ||y01>=430) {dy0=-dy0;}


    SDL_RenderPresent(m_renderer);
    SDL_Delay(25);
  SDL_RenderClear(m_renderer);

        if( SDL_PollEvent( event ) )
            {
                if( event->type == SDL_KEYDOWN )
                {
                    switch( event->key.keysym.sym )
                    {
                        case SDLK_ESCAPE:
                            {
                                SDL_DestroyWindow( m_window );
                                SDL_DestroyRenderer( m_renderer );
                                IMG_Quit();
                                SDL_Quit();
                                return 0;
                            }


                    }
                }
            }
        }
}


void window_color(SDL_Renderer *Renderer, int R, int G, int B)
{
    SDL_SetRenderDrawColor(Renderer,R,G,B,255);
    SDL_RenderClear(Renderer);
}
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian)
{

    SDL_Rect rectangle ;
    rectangle.x = x;
    rectangle.y = y;
    rectangle.w = w;
    rectangle.h = h;

    SDL_SetRenderDrawColor(Renderer, R, G, B, 255);
    SDL_RenderFillRect(Renderer, &rectangle);
    SDL_RenderDrawRect(Renderer, &rectangle);
    //SDL_RenderPresent(Renderer);
}
