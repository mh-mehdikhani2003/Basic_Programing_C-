#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_gfx.h>
#include <string>
#include <math.h>
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian);
void window_color(SDL_Renderer *Renderer, int R, int G, int B);
int maximum (int i[10])
{
    int temp=0;
   int  maximum=i[0];
    for(int j=1;j<10;j++)
    {
        if(maximum<i[j])
        {
            maximum=i[j];
        }
    }
       return(maximum);
}
bool    SDL_kbhit(){
  SDL_PumpEvents();
  return SDL_HasEvent(SDL_KEYDOWN);
}
using namespace std;


int main( int argc, char * argv[] )
{
    int W =700;
    int L = 1500;
    int i[10], h[10],x=10;double k=0;
    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
    Uint32 WND_flags = SDL_WINDOW_SHOWN;
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    SDL_Init( SDL_flags );
    SDL_CreateWindowAndRenderer( L, W, WND_flags, &m_window, &m_renderer );
    SDL_RaiseWindow(m_window);
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    window_color(m_renderer,98,232,208);
for(int j=0;j<10;j++)
{
    h[j]=0;i[j]=0;
}
i[9]=1;
    SDL_Event *event = new SDL_Event();

    while (1)
    {
    window_color(m_renderer,98,232,208);
    rect(m_renderer,0,0,1500,30,0,0,0,1);
    rect(m_renderer,0,30,30,640,0,0,0,1);
    rect(m_renderer,0,670,1500,30,0,0,0,1);
    rect(m_renderer,1470,30,30,640,0,0,0,1);
   SDL_PollEvent(event);
        if(event ->type == SDL_MOUSEBUTTONDOWN){
//SDL_PollEvent(event);
        if(SDL_BUTTON_LEFT)
            {

                x=rand()%10;

    if(x==1){
        i[1]++;}
    if(x==2){
        i[2]++;}
    if(x==3){
        i[3]++;}
    if(x==4){
        i[4]++;}
    if(x==5){
        i[5]++;}
    if(x==6){
        i[6]++;}
    if(x==7){
        i[7]++;}
    if(x==8){
        i[8]++;}
    if(x==9){
        i[9]++;}
    if(x==0){
        i[0]++;}

            }



    }



    for(int j=0;j<10;j++)
    {
       k=(double)i[j]/maximum(i);
        h[j]=(k*500);
    }
        for(int j=0;j<10;j++)
        {
         if(i[j]<10)
         {
             rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,255,255,1);
         }
         if(i[j]==10)
         {
              rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,232,232,1);
         }
          if(i[j]==11)
          {
               rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,209,209,1);
          }
           if(i[j]==12)
           {
                rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,186,186,1);
           }
            if(i[j]==13)
            {

                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,163,163,1);
            }
            if(i[j]==14)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,140,140,1);
            }
            if(i[j]==15)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,117,117,1);
            }
            if(i[j]==16)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,94,94,1);
            }
            if(i[j]==17)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,71,71,1);
            }
            if(i[j]==18)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,48,48,1);
            }
            if(i[j]==19)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,25,25,1);
            }
            if(i[j]==20)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,2,2,1);
            }
            if(i[j]>20)
            {
                 rect(m_renderer,35+(j*125),670-h[j],120,h[j],255,0,0,1);
            }

        }


    SDL_RenderPresent(m_renderer);
    SDL_Delay(60);
  SDL_RenderClear(m_renderer);

        if( SDL_PollEvent( event ) )
            {
                if( event->type == SDL_KEYDOWN )
                {
                    switch( event->key.keysym.sym )
                    {
                        case SDLK_ESCAPE:
                            {
                                SDL_DestroyWindow( m_window );
                                SDL_DestroyRenderer( m_renderer );
                                IMG_Quit();
                                SDL_Quit();
                                return 0;
                            }


                    }
                }
            }
        }
}


void window_color(SDL_Renderer *Renderer, int R, int G, int B)
{
    SDL_SetRenderDrawColor(Renderer,R,G,B,255);
    SDL_RenderClear(Renderer);
}
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian)
{

    SDL_Rect rectangle ;
    rectangle.x = x;
    rectangle.y = y;
    rectangle.w = w;
    rectangle.h = h;

    SDL_SetRenderDrawColor(Renderer, R, G, B, 255);
    SDL_RenderFillRect(Renderer, &rectangle);
    SDL_RenderDrawRect(Renderer, &rectangle);
    //SDL_RenderPresent(Renderer);
}
