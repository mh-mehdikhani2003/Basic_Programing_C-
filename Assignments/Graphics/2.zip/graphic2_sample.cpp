#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_gfx.h>
#include <string>
#include <math.h>
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian);
void window_color(SDL_Renderer *Renderer, int R, int G, int B);
void my_line(SDL_Renderer *Renderer, int x_1, int y_1, int L, double theta,int widht, int R, int G, int B );
using namespace std;

int main( int argc, char * argv[] )
{
    int W =700;
    int L = 1500;

    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
    Uint32 WND_flags = SDL_WINDOW_SHOWN;
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    SDL_Init( SDL_flags );
    SDL_CreateWindowAndRenderer( L, W, WND_flags, &m_window, &m_renderer );
    SDL_RaiseWindow(m_window);
    SDL_DisplayMode DM;
    SDL_GetCurrentDisplayMode(0, &DM);
    window_color(m_renderer,98,232,208);

    SDL_Event *event = new SDL_Event();
    int dx=15,dy=5,x=150,y=70,x0=1150    ,y0=20,dx0=-3;

    while (1)
    {
    window_color(m_renderer,98,232,208);
    rect(m_renderer,100,10,1300,10,0,0,0,1);
    rect(m_renderer,100,680,1300,10,0,0,0,1);
    rect(m_renderer,90,20,10,660,0,0,0,1);
    rect(m_renderer,1400,20,10,660,0,0,0,1);
 filledEllipseRGBA(m_renderer, x, y, 40, 40, 100, 200, 0, 255);
     rect(m_renderer,x0,y0,30,660,159,22,255,1);
   // x+=dx;
 //y+=dy,
//x0+=dx0;

  if(x<=140) {dx=-dx;}
  if(x+40>=x0)
    {

       if (dx>0 && dx!=3){
            dx=dx-3;
           dx=-dx;
        }
       if (dx>0  && dx==3)
       {
           dx=-dx;
       }
 }
    if(x0<=750 || x0>=1370) {dx0=-dx0;}
    if(y<=60 || y>=640) {dy=-dy;}
        x+=dx;
 y+=dy,
x0+=dx0;




    SDL_RenderPresent(m_renderer);
    SDL_Delay(25);
  SDL_RenderClear(m_renderer);

        if( SDL_PollEvent( event ) )
            {
                if( event->type == SDL_KEYDOWN )
                {
                    switch( event->key.keysym.sym )
                    {
                        case SDLK_ESCAPE:
                            {
                                SDL_DestroyWindow( m_window );
                                SDL_DestroyRenderer( m_renderer );
                                IMG_Quit();
                                SDL_Quit();
                                return 0;
                            }


                    }
                }
            }
        }
}


void window_color(SDL_Renderer *Renderer, int R, int G, int B)
{
    SDL_SetRenderDrawColor(Renderer,R,G,B,255);
    SDL_RenderClear(Renderer);
}
void rect(SDL_Renderer *Renderer, int x,int y,int w,int h,int R, int G, int B, int fill_boolian)
{

    SDL_Rect rectangle ;
    rectangle.x = x;
    rectangle.y = y;
    rectangle.w = w;
    rectangle.h = h;

    SDL_SetRenderDrawColor(Renderer, R, G, B, 255);
    SDL_RenderFillRect(Renderer, &rectangle);
    SDL_RenderDrawRect(Renderer, &rectangle);
    //SDL_RenderPresent(Renderer);
}

void my_line(SDL_Renderer *Renderer, int x_1, int y_1, int L, double theta,int widht, int R, int G, int B )

{

    int x_2 = x_1 + L*cos(theta);

    int y_2 = y_1 - L*sin(theta);







    thickLineRGBA(Renderer,x_1,y_1,x_2,y_2,widht,R,G,B,255);

  //  SDL_RenderPresent(Renderer);



}

