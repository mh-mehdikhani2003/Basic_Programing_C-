#include <iostream>
#include <fstream>
#include <string.h>
#include <string>
using namespace std;
string x;
void SHIFT_R(int n)
{
    string xprim=x;
    for(int j=1;j<=n;j++)
    {
        for(int i=0;i<x.length()-1;i++)
        {
            x[i+1]=xprim[i];
        }
        x[0]=xprim[x.length()-1];
         xprim=x;
    }
}
void SHIFT_L (int n)
{
  
    string xprim=x;
    for(int j=1;j<=n;j++)
    {
        for(int i=0;i<x.length()-1;i++)
        {
            x[i]=xprim[i+1];
        }
        x[x.length()-1]=xprim[0];
        xprim=x;
    }
}
void EXTEND (int  n)
{
    string star="*";
    string xprim;
    for(int i=1;i<=n;i++)
    {
        xprim=xprim+star;
    }
    x=x+xprim;
}
void SHRINK(int n)
{
    if(x.length()<n)
    {
        x.erase(0,x.length());
        return;
    }
    else{
    x.erase(x.length()-n,x.length());}
}
void swap(int i,int a)
{
    char temp=x[i];
    x[i]=x[a];
    x[a]=temp;
}
void REVERSE()
{
    for(int i=0;i<=(x.length()/2)-1;i++)
    {
        swap(i,x.length()-1-i);
    }
}
void PUT (int I,char c)
{
    x[I-1]=c;
}
string mysubstr (string x, int n, int h)
{
	string split = "";
	for(   ;n <= h; n++)
    {
        split += x[n];
    }
	
	return (split);
}
void emal_dastoorat(string c)
{
    string x_2=c;
    int z=0,b=0;
    string adad=c;
    while (adad[b]!='0' &&adad[b]!='1' &&adad[b]!='2' &&adad[b]!='3'  &&adad[b]!='4' && adad[b]!='5' && adad[b]!='6' &&adad[b]!='7' &&adad[b]!='8' && adad[b]!='9'   && b<c.length())
    {
        b++;
    }
    b--;
    adad.erase(0,b+1);
    for(int i=0;i<adad.length();i++)
    {
        z*=10;
        z+=adad[i]-48;
    }
    b=0;
    while (adad[b]!=' ')
    {
        b++;
    }
    if(b<x_2.length())
    {
     x_2.erase(b,x_2.length()-1);   
    }
    
    if(x_2=="SHIFT-R"){SHIFT_R(z);}
    if(x_2=="SHIFT-L"){SHIFT_L(z);}
    if(x_2=="EXTEND"){EXTEND(z);}
    if(x_2=="SHRINK"){SHRINK(z);}
    if(c=="REVERSE"){REVERSE();}
    if(c[0]=='P' && c[1]=='U'  && c[2]=='T')
    {
    
    int h=0,n=0,dasht=0;
    for(int i=0;i<c.length();i++)
    {
     
        if(c[0]!=' ' && i==0){dasht++;}
        if((c[i]==' ') &&  (c[i+1]!=' ') && (i!=c.length()-1)){dasht++;}
        
    }
    string A[dasht];
    int komak=dasht-1;
    for(int i=c.length()-1;i>=0;i--)
    {
        if(c[c.length()-1]!=' ' && i==c.length()-1){h=i;}
        if((c[i]!=' ') &&  (c[i+1]==' ') && (i!=c.length()-1)){h=i;}
        if((c[i]!=' ') &&  (c[i-1]==' ') && (i!=0)){n=i;A[komak]=mysubstr(c,n,h),komak--;}
        if(c[0]!=' ' && i==0){n=i;A[komak]=mysubstr(c,n,h),komak--;}

    }
    int I=0;
    char V=A[2].at(0); 
    for(int i=0;i<A[1].length();i++)
    {
        I*=10;
        I+=A[1].at(i)-48;
    }
    PUT(I,V);
    }
}
int main()
{
    string c,ADDR;
    cin>>x;
    ADDR="E:\\"+x;

    ifstream file;
    file.open(ADDR);
    ofstream your_file;
    your_file.open(ADDR);
    getline(file,x);
    while(!file.eof())
    {
        getline(file,c);
        if(c=="EXIT"){break;}
        if(c=="PRINT"){your_file<<x<<"\n";}
        emal_dastoorat(c);
    }
   file.close();
    your_file.close();
    return 0;
}
