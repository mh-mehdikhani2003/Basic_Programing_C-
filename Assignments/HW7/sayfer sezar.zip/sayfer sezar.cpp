#include <iostream>
#include <fstream>
#include <string.h>
#include <string>
using namespace std;
void check_bozorg (string x,int i)
{
    while (x[i]>90)
    {
        x[i]-=90;
        x[i]+=64;
    }
}
void check_koochik (string x,int i)
{
    while (x[i]>122)
    {
        x[i]-=122;
        x[i]+=96;
    }
}
int main()
{
    string x,ADDR;
    cin>>x;
    ADDR="E:\\"+x;
    int n;
    cin>>n;
    ifstream file;
    file.open(ADDR);
    ofstream your_file;
    your_file.open(ADDR);
    while(!file.eof())
    {
        getline(file,x);    
        for(int i=0;i<x.length();i++)
        {
        if(x[i]==' '){continue;}
        if(x[i]>=65 && x[i]<=90)
        {
            x[i]+=n;
            check_bozorg(x,i);
        }
        if(x[i]>=97  && x[i]<=122)
        {
            x[i]+=n;
            check_koochik(x,i);
        }
        }
        your_file<<x<<"\n";
    }
   file.close();
    your_file.close(); 
    return 0;
}
